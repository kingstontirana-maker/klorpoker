# Analiza funksionale e Baron Poker

Platforma është një prototip i luajtshëm Texas Hold’em me kredit virtual. Baza e lojës ekzistonte, por hyrja e përbashkët në tavolinë dhe mungesa e afateve e bënin rrjedhën të paqartë. Tani hyrja ndahet sipas rolit.

## Hierarkia

| Roli | Paneli dhe përgjegjësitë |
| --- | --- |
| Center / Qendra | Krijon administratorë, shpërndan/rikthen kredit, krijon tavolina, cakton rake, shikon regjistrin global. |
| Admin | Krijon agjentë, menaxhon kreditin e tyre dhe shikon transfertat e veta. |
| Agent | Krijon lojtarë, shpërndan/rikthen kreditin e portofolit dhe shikon transfertat e veta. |
| Lojtari | Hyn në lobby, zgjedh tavolinën dhe vendin, vendos buy-in, luan dhe rikthen çipat në portofol kur largohet. |

Lejet kontrollohen në server. Operatorët nuk luajnë nga llogaria e menaxhimit. Një operator nuk transferon kredit drejtpërdrejt te një llogari jashtë vartësve të vet direkt.

## Rrjedha e lojtarit

1. Login → lobby me blinds, vende të zëna dhe kufij buy-in.
2. Portofoli zero → tavolina nuk hapet; kërkohet kredit nga agjenti.
3. Zgjedhja e vendit dhe buy-in zbresin kredit nga portofoli dhe vendosin çipa në tavolinë. Lejohet vetëm një tavolinë për lojtar.
4. Dy lojtarë me çipa të mjaftueshëm nisin dorën. Serveri drejton blinds, radhën, board, all-in, side pots dhe shpërndarjen.
5. Çdo veprim ka 30 sekonda. Pas afatit serveri bën auto-fold. Dy duar radhazi pa veprim shkaktojnë largim përpara dorës së tretë, me kthim të çipave në portofol. Veprimi manual e zeron numërimin.
6. Pas përfundimit të dorës, rezultati, letrat fituese dhe animimet shfaqen për tetë sekonda. Nëse lojtari ka zero çipa ose më pak se big blind, më pas hapet kërkesa për riblerje me 30 sekonda të plota. Afati ruhet në server dhe vazhdon edhe pa shfletuesin.
7. Riblerja përdor portofolin. Nëse është bosh, agjenti duhet ta furnizojë brenda afatit. Pa riblerje lojtari largohet dhe çipat e mbetur kthehen në portofol.

Portofoli dhe çipat në tavolinë janë dy gjendje të ndryshme. Portofoli zero gjatë lojës nuk largon një lojtar që ka çipa në tavolinë. All-in me zero çipa pret përfundimin e dorës sepse lojtari mund të fitojë pot-in.

## Saktësia dhe qëndrueshmëria

Janë shtuar afatet autoritative, lojërat automatike, riblerja, bllokimi i hyrjes pa kredit, privatësia e letrave pas fold, emrat e fituesve, kufizimi i rihapjes së raise pas një all-in të paplotë dhe kthimi i basteve të pakonkurruara pa rake. Rake kreditohet te Qendra. Snapshot-i ruan portofolin dhe çipat/kontributet; pas rinisjes dora anulohet dhe shumat e ruajtura kthehen në portofol.

## Çfarë mbetet

Kjo nuk është ende një platformë e përfunduar për para reale. Mungojnë databaza transaksionale dhe regjistri kontabël i pandryshueshëm, rikthimi i plotë i dorës pas crash, verifikimi i pavarur i motorit, rregulli i plotë për rihapjen nga disa all-in të vogla radhazi, shpërndarja e odd chips sipas pozicionit ndaj dealer-it, politika e missed blinds/sit-out, mbrojtja ndaj bashkëpunimit dhe abuzimit, menaxhimi i sesioneve për përdorim publik, pagesat dhe proceset përkatëse të operatorit.

Testet automatike mbulojnë vlerësimin e duarve, side pots, rake, lejet e hierarkisë, hyrjen pa kredit, riblerjen, ruajtjen e çipave dhe largimin pas afatit. Pamja në shfletues duhet të verifikohet gjithashtu në pajisjet ku do të përdoret.


## Përmirësimi i tavolinës dhe animimeve

Problemet e pamjes ishin letrat e vogla, mungesa e çipave fizikë, mungesa e një numërimi të vazhdueshëm dhe rindërtimi i elementeve në çdo poll. Gjithashtu rezultati nuk përmbante kombinimin e saktë me pesë letra.

Tavolina tani ruan elementet e pandryshuara, pozicionon lojtarin lokal në fund dhe paraqet letra më të mëdha, të vendosura drejt dhe në qendër mbi avatarin e tij. Çipat kanë prerje, ngjyra, buzë dhe shtresa; vlera numerike mbetet burimi i saktë i shumës. Serveri lëshon ngjarje publike me numër rendor për deal, blinds, bets, check, fold, streets dhe payout. Klienti konsumon secilën vetëm një herë; hyrja në mes të një dore nuk riprodhon historikun e animimeve.

Bastet lëvizin nga avatari drejt pot-it dhe fitimi nga pot-i drejt marrësit. Kartat shpërndahen me animim, ndërsa letrat e kundërshtarëve mbeten të fshehta sipas rregullave të serverit. Në showdown serveri llogarit pesë letrat konkrete të fituesit. Vetëm këto theksohen me glow; letrat e tjera zbehen. Për disa fitues ose side pots mund të zgjidhet fituesi për të parë kombinimin e tij. Kthimi i një kontributi të pakonkurruar nuk etiketohet si fitore e pot-it.

Unaza SVG llogaritet nga afati i serverit, vazhdon ndërmjet poll-eve dhe ndryshon ngjyrë në 10 dhe 5 sekondat e fundit. Kontrollet përfshijnë All-in, Min, gjysmën e pot-it, Pot dhe Max. Shuma që lojtari po redakton nuk mbishkruhet nga polling. Dërgimi i dyfishtë i veprimit bllokohet gjatë kërkesës. Janë shtuar statusi i lidhjes, tinguj opsionalë, aktivizimi/ndalimi i animimeve, ekrani i plotë, historia e palosshme dhe afati i dorës së ardhshme. Pauza ndërmjet duarve është tetë sekonda për të lexuar rezultatin.

Verifikimi: testet e motorit dhe të të dhënave vizuale, si dhe një skenar real në Chrome për 1440px, 390px dhe 320px. Skenari i shfletuesit përdor të dhëna të izoluara dhe nuk prek llogaritë ose balancat reale. Pamjet ruhen te `artifacts/`. Transporti mbetet polling çdo 1.3 sekonda; ngjarjet ruajnë veprimet ndërmjet kërkesave, por nuk japin vonesën e ulët të WebSocket. Zbatimi i plotë i WebSocket dhe rikthimi i dorës pas restart mbeten punë të veçanta.


### Përshtatja sipas referencës së tavolinës

Vendet e lira janë butona rrethorë JOIN që hapin formularin e buy-in. Çdo lojtar ka vetëm dy letra të ndara, në të njëjtin rresht dhe të qendruara mbi avatarin. Një komponent i përbashkët përcakton madhësinë dhe hapësirën sipas ekranit. Pakoja dekorative dhe kopja e dytë e dorës janë hequr. Shiriti i veprimeve përdor tre butona kryesorë: Fold, Check ose Call sipas shumës për t'u ndjekur dhe Raise. Shuma, slider-i dhe butonat −/+ janë në të djathtë në desktop dhe poshtë në telefon. All-in dhe madhësitë e paracaktuara qëndrojnë në një rresht dytësor. Nuk shfaqet një kopje e dytë e letrave te kontrollet.


### Organizimi brenda ekranit dhe pasiviteti

Tavolina përdor lartësinë e ekranit, me shirit të sipërm, skenë responsive që ndryshon madhësinë e felt-it pa zvogëluar letrat ose tekstet, kontrolle kompakte dhe shirit ndihmës poshtë. Historiku hapet si panel me scroll brenda vetes. Simbolet qendrore të letrave janë SVG të qendruara në të dy akset; pamja e letrave është modernizuar. Pozicionet e animimeve përshtaten me shkallëzimin e skenës.

Serveri numëron auto-fold sipas dorës, jo sipas numrit të kërkesave ose poll-eve. Pas dy duarve pa veprim, lojtari hiqet para blinds të dorës së tretë. Çipat e mbetur kthehen të plotë dhe dalja regjistrohet me arsyen INACTIVE. Një veprim manual i vlefshëm e zeron numëruesin. Lojtari merr paralajmërim dhe kthehet në lobby pas largimit.


### Lexueshmëria responsive

U hoq plotësisht transformimi scale i skenës dhe matja automatike që zvogëlonte të gjithë tavolinën. Tavolina shtrihet në gjerësinë e ekranit, ndërsa letrat personale kanë 68 px gjerësi në PC dhe 63 px në telefon, me numra dhe simbole më të mëdha, avatarët dhe emrat ruajnë madhësitë e tyre dhe butonat kryesorë kanë lartësi të paktën 44 px. Në ekrane të ulëta lejohet scroll vertikal në vend të teksteve dhe letrave shumë të vogla. Rreshtat anësorë të lojtarëve kanë ndarje më të madhe vertikale që emrat të mos mbulojnë letrat e një lojtari tjetër. Në telefon, vendet anësore shtrihen në skajet e tavolinës për të liruar letrat qendrore.


### Forma e qëndrueshme e tavolinës

U hoq lartësia e pavarur nga gjerësia që deformonte felt-in. Tani gjerësia dhe lartësia llogariten së bashku me raport 2.3:1 në desktop dhe 0.9:1 në telefon vertikal. Skajet janë të rrumbullakosura me segmente të drejta, në vend të elipsit të zgjatur. ResizeObserver mat vetëm hapësirën e skenës dhe ndryshon dimensionet e felt-it; nuk përdoret scale për letrat, emrat ose butonat. Në ekranet shumë të ulëta ruhet madhësia e lexueshme me scroll vertikal.


### Korrigjimi i tavolinës bosh

Llogaritja e mëparshme ruante raportin e felt-it por lejonte që lartësia e vogël e dritares ta zvogëlonte nën hapësirën e nevojshme për gjashtë vende. Tani skena ka një minimum të llogaritur nga gjerësia e disponueshme dhe madhësia e lexueshme e tavolinës: deri në 900 px minimum në desktop, i kufizuar nga gjerësia e dritares; në telefon përdoret gjerësia e disponueshme. Faqja zgjatet vertikalisht kur mungon lartësia. Testi real në Chrome kontrollon tavolinën bosh me gjashtë JOIN dhe verifikon që asnjë çift butonash nuk mbivendoset në shtatë madhësi dritaresh, përfshirë 510×300 dhe 844×390. Pamjet e verifikimit janë `artifacts/table-empty-desktop.png`, `artifacts/table-empty-short.png` dhe `artifacts/table-empty-mobile.png`.


### Simbolet dhe glow i fituesit

Të katër simbolet përdorin të njëjtat forma SVG në qendër dhe në cepat e letrës. Numri/shkronja dhe simboli i cepit janë brenda një koordinimi SVG fiks, për të shmangur ndryshimet e fonteve dhe mbivendosjen me simbolin qendror. Shenja trefletëshe përdor tre rrathë simetrikë me bisht të veçantë. Ngjyrat janë të kuqe për zemër/karo dhe të errëta për spathi/trefletësh. Glow dhe bordura e pesë letrave fituese janë jeshile; letrat që nuk formojnë kombinimin e zgjedhur mbeten të zbehura. Testet kontrollojnë të 52 letrat, ndërsa skenari në Chrome verifikon edhe ngjyrën reale të bordurës dhe hijes së fituesit.


### Rezultati para kërkesës për kredit

Serveri cakton `rebuyAvailableAt` tetë sekonda pas rezultatit dhe afatin `rebuyDeadline` tridhjetë sekonda pas këtij momenti. Klienti nuk hap dialogun para kohës së serverit, kështu që dritarja nuk mbulon menjëherë letrat dhe fituesin. Testi në Chrome kontrollon që dialogu është i mbyllur gjatë shfaqjes së rezultatit dhe hapet më pas. Testi i integrimit kontrollon afatin e plotë të kreditit dhe që lojtari mbetet në vend deri në përfundimin e tij.

### Saktësia dhe përditësimi live i rake

Rake përllogaritet mbi kontributet e konkurruara, me rrumbullakim kumulativ në cent dhe kufi për të gjithë dorën. Side pots nuk shkaktojnë më humbje centësh nga rrumbullakime të veçuara. Ruajtja dhe kreditimi kryhen në fund të dorës; panelet e stafit marrin menjëherë snapshot-in e ri me një stream SSE të autentikuar dhe rilidhje automatike. Lojtarët nuk kanë akses në stream. Regjistrimet historike pa ndarje nuk u ndryshuan.
